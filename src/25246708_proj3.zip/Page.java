import java.util.ArrayList;

/**
 * Created by raeleneg on 3/1/17.
 */
public class Page {
    public int page;
    public int address;
}
