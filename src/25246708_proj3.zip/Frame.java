/**
 * Created by raeleneg on 3/5/17.
 */
public class Frame {
    public static int[] bits = new int[512];
}
