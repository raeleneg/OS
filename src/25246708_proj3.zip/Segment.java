import java.util.ArrayList;

/**
 * Created by raeleneg on 3/1/17.
 */
public class Segment {

    public int segment;
    public int address;
    public ArrayList<Page> pages;


}
