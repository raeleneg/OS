/**
 * Created by raeleneg on 3/6/17.
 */
public class TLB {
    public int s;
    public int p;
    public int address;
}
